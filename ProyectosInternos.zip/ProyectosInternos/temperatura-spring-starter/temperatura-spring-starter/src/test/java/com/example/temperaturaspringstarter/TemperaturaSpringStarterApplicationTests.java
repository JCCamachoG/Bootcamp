package com.example.temperaturaspringstarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperaturaSpringStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
