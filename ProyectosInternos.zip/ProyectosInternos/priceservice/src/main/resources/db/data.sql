
INSERT INTO prices (code_product, description, price) VALUES ('PRODCT_0001', 'Chanclas', 10.5);
INSERT INTO prices (code_product, description, price) VALUES ('PRODCT_0002', 'Botines', 20.25);
INSERT INTO prices (code_product, description, price) VALUES ('PRODCT_0003', 'Sudadera', 30.75);
INSERT INTO prices (code_product, description, price) VALUES ('PRODCT_0004', 'Raqueta', 30.75);
INSERT INTO prices (code_product, description, price) VALUES ('PRODCT_0005', 'Balon', 50.05);
INSERT INTO prices (code_product, description, price) VALUES ('PRODCT_0006', 'Skies', 100.75);
INSERT INTO prices (code_product, description, price) VALUES ('PRODCT_0007', 'Guantes', 25.05);
INSERT INTO prices (code_product, description, price) VALUES ('PRODCT_0008', 'Gorra', 33.75);
INSERT INTO prices (code_product, description, price) VALUES ('PRODCT_0009', 'Piolets', 80.75);
