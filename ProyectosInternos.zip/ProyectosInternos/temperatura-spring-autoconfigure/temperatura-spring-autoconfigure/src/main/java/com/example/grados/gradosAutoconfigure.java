package com.example.grados;

import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.temperaturaspringautoconfigure.gradosProperties;

import com.example.temperaturalibreria.Temperatura;

@Configuration
@ConditionalOnClass(Temperatura.class)
@EnableConfigurationProperties(gradosProperties.class)
public class gradosAutoconfigure {

	private final gradosProperties properties;

	public gradosAutoconfigure(gradosProperties properties) {
		this.properties = properties;
	}
	
	@Bean
	public Grados grados() {
		return new Grados(properties.getGrados());
	}
	
}