package com.example.temperaturaspringautoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

public class gradosProperties {
	@ConfigurationProperties("temperatura.mensaje")
	@Getter
	@Setter
	public class GradosProperties {
		
		private String temperatura = "Celsius";

	}
}
